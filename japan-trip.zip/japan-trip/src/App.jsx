import { useState, useEffect, useCallback, useRef } from "react";

// ── DEFAULT DATA ───────────────────────────────────────────────────────────────
const DEFAULT_CARDS = [
  { id:"t1",  city:"tokyo",   date:"Aug 18 · Day 1",       title:"Shibuya & Harajuku",    note:"", activities:["Shibuya Crossing","Hachiko Statue","Meiji Shrine","Takeshita Street"], files:[] },
  { id:"t2",  city:"tokyo",   date:"Aug 19 · Day 2",       title:"Asakusa & Akihabara",   note:"", activities:["Senso-ji Temple","Nakamise Street","Tokyo Skytree","Akihabara – anime & gaming district"], files:[] },
  { id:"t3",  city:"tokyo",   date:"Aug 20 · Day 3",       title:"Shinjuku",              note:"", activities:["Shinjuku exploration","Omoide Yokocho alley","Tokyo Metropolitan Govt Building observation deck","teamLab digital art museum"], files:[] },
  { id:"tr1", city:"transit", date:"Aug 21 · Transit",     title:"Tokyo → Kyoto",         note:"", transit:{from:"TYO",to:"KYO",time:"~2.5 hrs",cost:"≈ $110/person"}, files:[] },
  { id:"k1",  city:"kyoto",   date:"Aug 22 · Day 1",       title:"Fushimi Inari & Gion",  note:"", activities:["Fushimi Inari Taisha – torii gate shrine","Gion district","Yasaka Shrine"], files:[] },
  { id:"k2",  city:"kyoto",   date:"Aug 23 · Day 2",       title:"Arashiyama",            note:"", activities:["Arashiyama Bamboo Grove","Tenryu-ji Temple","Togetsukyo Bridge","Optional: Monkey Park"], files:[] },
  { id:"k3",  city:"kyoto",   date:"Aug 24 · Day 3",       title:"Kibune Day Trip",       note:"~1 hr north of Kyoto · cooler mountain atmosphere", activities:["Kifune Shrine","Riverside kawadoko dining platforms","Optional hike toward Kurama"], files:[] },
  { id:"tr2", city:"transit", date:"Aug 25 · Transit",     title:"Kyoto → Osaka",         note:"", transit:{from:"KYO",to:"OSA",time:"~30 min",cost:"≈ $10/person"}, files:[] },
  { id:"o1",  city:"osaka",   date:"Aug 26 · Day 1",       title:"Dotonbori",             note:"", activities:["Dotonbori canal","Glico Running Man sign","Shinsekai district","Street food – takoyaki & okonomiyaki"], files:[] },
  { id:"o2",  city:"osaka",   date:"Aug 27 · Day 2",       title:"Choice Day",            note:"Pick one – evening Shinkansen back to Tokyo", activities:["Option A: Universal Studios Japan – Super Nintendo World","Option B: Osaka Castle + park area"], files:[] },
  { id:"tr3", city:"transit", date:"Aug 27 eve · Transit", title:"Osaka → Tokyo",         note:"", transit:{from:"OSA",to:"TYO",time:"~2.5–3 hrs",cost:"≈ $110/person"}, files:[] },
  { id:"fly", city:"transit", date:"Aug 28 · Final Day",   title:"Fly Home ✈",            note:"", transit:{from:"NRT",to:"HOME",time:"Departure",cost:"Narita / Haneda"}, files:[] },
];

const CITY_COLORS = {
  tokyo:   { accent:"#6b82c0", bg:"rgba(107,130,192,0.13)", border:"rgba(107,130,192,0.32)", text:"#a0b0e0" },
  kyoto:   { accent:"#c08080", bg:"rgba(192,128,128,0.13)", border:"rgba(192,128,128,0.32)", text:"#e0a0a0" },
  osaka:   { accent:"#60c090", bg:"rgba(96,192,144,0.13)",  border:"rgba(96,192,144,0.32)",  text:"#80d0a8" },
  transit: { accent:"#9b80c0", bg:"rgba(155,128,192,0.13)", border:"rgba(155,128,192,0.32)", text:"#c0a8e0" },
};
const CITY_LABELS = { tokyo:"Tokyo", kyoto:"Kyoto", osaka:"Osaka", transit:"Transit" };
const uid = () => Math.random().toString(36).slice(2,9);

// ── CSS ────────────────────────────────────────────────────────────────────────
const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Shippori+Mincho:wght@400;600;700&family=DM+Mono:wght@300;400&family=Unbounded:wght@300;400;700&display=swap');
  *, *::before, *::after { box-sizing:border-box; margin:0; padding:0; -webkit-tap-highlight-color:transparent; }
  html, body { background:#0d0d0d; overflow-x:hidden; }
  input, textarea { font-family:'DM Mono',monospace; outline:none; background:transparent; color:#f5f0e8; }
  input::placeholder, textarea::placeholder { color:rgba(255,255,255,0.18); }
  button { font-family:'DM Mono',monospace; cursor:pointer; }
  textarea { resize:none; }
  ::-webkit-scrollbar { display:none; }
  scrollbar-width: none;

  @keyframes fadeUp { from{opacity:0;transform:translateY(13px)} to{opacity:1;transform:translateY(0)} }
  @keyframes sheetIn { from{transform:translateY(100%)} to{transform:translateY(0)} }
  @keyframes overlayIn { from{opacity:0} to{opacity:1} }
  @keyframes toastIn { from{opacity:0;transform:translateX(-50%) translateY(8px)} to{opacity:1;transform:translateX(-50%) translateY(0)} }
  @keyframes spin { to{transform:rotate(360deg)} }
  @keyframes shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }

  .fadeup { animation:fadeUp .35s ease both; }
  .sheet  { animation:sheetIn .3s cubic-bezier(.32,.72,0,1) both; }
  .overlay { animation:overlayIn .2s ease both; }
  .toastin { animation:toastIn .25s ease both; }
  .spinner { animation:spin 1s linear infinite; }

  .card:hover { background:rgba(255,255,255,0.035) !important; }
  .add-btn:hover { border-color:rgba(255,255,255,0.25) !important; color:#fdfaf5 !important; }
  .edit-btn:hover { background:rgba(255,255,255,0.09) !important; color:#fdfaf5 !important; }
  .file-chip:hover { background:rgba(255,255,255,0.08) !important; }
  .file-chip:hover .chip-del { opacity:1 !important; }

  .drop-zone { transition: border-color .2s, background .2s; }
  .drop-zone.drag-active { border-color:rgba(255,255,255,0.35) !important; background:rgba(255,255,255,0.05) !important; }

  .img-thumb { object-fit:cover; width:100%; height:100%; border-radius:5px; display:block; }
  .lightbox-img { max-width:90vw; max-height:80vh; border-radius:8px; object-fit:contain; }
`;

// ── API HELPERS ────────────────────────────────────────────────────────────────
async function loadState() {
  const res = await fetch('/api/state');
  if (!res.ok) throw new Error('load failed');
  return res.json();
}

async function saveState(data) {
  await fetch('/api/state', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(data),
  });
}

async function uploadFile(cardId, file) {
  const form = new FormData();
  form.append('file', file);
  form.append('cardId', cardId);
  const res = await fetch('/api/upload', { method:'POST', body: form });
  if (!res.ok) throw new Error('upload failed');
  return res.json(); // { url, name, type, size }
}

async function deleteFile(url) {
  await fetch('/api/upload', {
    method:'DELETE',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ url }),
  });
}

// ── APP ────────────────────────────────────────────────────────────────────────
export default function App() {
  const [cards,     setCards]     = useState(DEFAULT_CARDS);
  const [order,     setOrder]     = useState(() => DEFAULT_CARDS.map(d => d.id));
  const [checked,   setChecked]   = useState({});
  const [collapsed, setCollapsed] = useState({});
  const [filter,    setFilter]    = useState("all");
  const [saving,    setSaving]    = useState(false);
  const [loaded,    setLoaded]    = useState(false);
  const [toast,     setToast]     = useState(null);
  const [editCard,  setEditCard]  = useState(null);
  const [confirmDel,setConfirmDel]= useState(null);
  const [lightbox,  setLightbox]  = useState(null); // { url, name }

  const dragSrc  = useRef(null);
  const touchDrag = useRef(null);
  const touchTgt  = useRef(null);
  const holdTimer = useRef(null);
  const saveTimer = useRef(null);

  // ── LOAD ──
  useEffect(() => {
    loadState()
      .then(d => {
        if (d.cards)     setCards(d.cards);
        if (d.order)     setOrder(d.order);
        if (d.checked)   setChecked(d.checked);
        if (d.collapsed) setCollapsed(d.collapsed);
      })
      .catch(() => {})
      .finally(() => setLoaded(true));
  }, []);

  // ── SAVE (debounced) ──
  const persist = useCallback((c, o, ch, col) => {
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      setSaving(true);
      try { await saveState({ cards:c, order:o, checked:ch, collapsed:col }); }
      catch(e) {}
      setSaving(false);
    }, 800);
  }, []);

  const upd = (nc, no, nch, ncol) => {
    const c=nc??cards, o=no??order, ch=nch??checked, col=ncol??collapsed;
    if(nc) setCards(c); if(no) setOrder(o); if(nch) setChecked(ch); if(ncol) setCollapsed(col);
    persist(c, o, ch, col);
  };

  const toggleCheck    = key => upd(null, null, {...checked, [key]:!checked[key]}, null);
  const toggleCollapse = id  => upd(null, null, null, {...collapsed, [id]:!collapsed[id]});

  const saveCard = edited => {
    upd(cards.map(c => c.id===edited.id ? edited : c), null, null, null);
    setEditCard(null);
    showToast("Saved ✓");
  };

  const addCard = () => {
    const nc = { id:uid(), city:"tokyo", date:"New Day", title:"Untitled", note:"", activities:[""], files:[] };
    upd([...cards, nc], [...order, nc.id], null, null);
    setEditCard({...nc});
  };

  const deleteCard = id => {
    upd(cards.filter(c=>c.id!==id), order.filter(i=>i!==id),
      Object.fromEntries(Object.entries(checked).filter(([k])=>!k.startsWith(id+"-"))), null);
    setConfirmDel(null);
    if (editCard?.id===id) setEditCard(null);
  };

  // file attached to a card
  const attachFile = (cardId, fileObj) => {
    const nc = cards.map(c => c.id===cardId ? {...c, files:[...(c.files||[]), fileObj]} : c);
    upd(nc, null, null, null);
  };
  const removeFile = async (cardId, fileUrl) => {
    try { await deleteFile(fileUrl); } catch(e) {}
    const nc = cards.map(c => c.id===cardId ? {...c, files:(c.files||[]).filter(f=>f.url!==fileUrl)} : c);
    upd(nc, null, null, null);
  };

  // ── DRAG ──
  const onDragStart = (e, id) => { dragSrc.current=id; e.dataTransfer.effectAllowed="move"; };
  const onDragOver  = e => e.preventDefault();
  const onDrop = (e, tid) => {
    e.preventDefault();
    if (!dragSrc.current || dragSrc.current===tid) return;
    const arr=[...order], si=arr.indexOf(dragSrc.current), ti=arr.indexOf(tid);
    arr.splice(si,1); arr.splice(ti,0,dragSrc.current);
    upd(null,arr,null,null);
    dragSrc.current=null;
  };

  // ── TOUCH DRAG ──
  const onTouchStart = (e, id) => {
    holdTimer.current = setTimeout(()=>{ touchDrag.current=id; if(navigator.vibrate)navigator.vibrate(30); }, 320);
  };
  const onTouchMove = e => {
    if (holdTimer.current) { clearTimeout(holdTimer.current); holdTimer.current=null; }
    if (!touchDrag.current) return;
    e.preventDefault();
    const {clientY}=e.touches[0];
    let found=null;
    for (let el of document.querySelectorAll("[data-card-id]")) {
      const r=el.getBoundingClientRect();
      if (clientY>=r.top && clientY<=r.bottom && el.dataset.cardId!==touchDrag.current) { found=el.dataset.cardId; break; }
    }
    touchTgt.current=found;
    if (clientY<80) window.scrollBy(0,-8);
    if (clientY>window.innerHeight-80) window.scrollBy(0,8);
  };
  const onTouchEnd = () => {
    if (holdTimer.current) { clearTimeout(holdTimer.current); holdTimer.current=null; }
    if (!touchDrag.current) return;
    if (touchTgt.current && touchTgt.current!==touchDrag.current) {
      const arr=[...order], si=arr.indexOf(touchDrag.current), ti=arr.indexOf(touchTgt.current);
      arr.splice(si,1); arr.splice(ti,0,touchDrag.current);
      upd(null,arr,null,null);
    }
    touchDrag.current=null; touchTgt.current=null;
  };

  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) await navigator.share({title:"Japan Trip · Aug 2026", url});
      else { await navigator.clipboard.writeText(url); showToast("Link copied — send it to your friend 🎌"); }
    } catch(e) { try { await navigator.clipboard.writeText(url); showToast("Link copied!"); } catch(e2) {} }
  };

  const showToast = (msg, dur=2800) => { setToast(msg); setTimeout(()=>setToast(null), dur); };

  const allKeys   = cards.flatMap(c=>(c.activities||[]).map((_,i)=>`${c.id}-${i}`));
  const doneCount = allKeys.filter(k=>checked[k]).length;
  const pct       = allKeys.length ? Math.round(doneCount/allKeys.length*100) : 0;
  const circ=113, offset=circ-(pct/100)*circ;

  const orderedCards = order.map(id=>cards.find(c=>c.id===id)).filter(Boolean);
  const visible      = filter==="all" ? orderedCards : orderedCards.filter(c=>c.city===filter);

  if (!loaded) return (
    <div style={{background:"#0d0d0d",minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",color:"rgba(255,255,255,0.2)",fontFamily:"monospace",fontSize:11,letterSpacing:"0.25em"}}>
      LOADING...
    </div>
  );

  return (
    <div style={{background:"#0d0d0d",minHeight:"100vh",fontFamily:"'DM Mono',monospace",color:"#f5f0e8",paddingBottom:116,userSelect:"none"}}>
      <style>{CSS}</style>

      {/* grain */}
      <div style={{position:"fixed",inset:0,backgroundImage:`url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.04'/%3E%3C/svg%3E")`,pointerEvents:"none",zIndex:999,opacity:0.5}}/>

      {/* ── HEADER ── */}
      <div style={{padding:"48px 20px 18px",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",inset:0,background:"radial-gradient(ellipse at 15% 60%,rgba(192,57,43,0.18) 0%,transparent 55%),radial-gradient(ellipse at 85% 15%,rgba(44,62,107,0.22) 0%,transparent 50%)"}}/>
        <div style={{fontFamily:"'Shippori Mincho',serif",fontSize:84,color:"rgba(255,255,255,0.034)",position:"absolute",right:-8,top:-10,lineHeight:1,pointerEvents:"none",letterSpacing:-2}}>日本</div>
        <div style={{fontSize:9,letterSpacing:"0.28em",textTransform:"uppercase",color:"#c0392b",marginBottom:8,position:"relative"}}>✈ Aug 18–28, 2026</div>
        <div style={{fontFamily:"'Unbounded',sans-serif",fontSize:"clamp(30px,8vw,44px)",fontWeight:700,lineHeight:1,letterSpacing:-1,color:"#fdfaf5",position:"relative",marginBottom:4}}>Japan</div>
        <div style={{fontFamily:"'Shippori Mincho',serif",fontSize:14,color:"#8a7f6e",position:"relative",marginBottom:22}}>Tokyo · Kyoto · Osaka</div>
        <div style={{display:"flex",gap:18,position:"relative",alignItems:"center"}}>
          {[["11","Days"],["3","Cities"],["~$330","Transport"],[`${doneCount}/${allKeys.length}`,"Done"]].flatMap(([v,l],i,a)=>[
            <div key={i} style={{display:"flex",flexDirection:"column",gap:2}}>
              <div style={{fontFamily:"'Unbounded',sans-serif",fontSize:17,color:"#fdfaf5"}}>{v}</div>
              <div style={{fontSize:7,letterSpacing:"0.22em",textTransform:"uppercase",color:"#8a7f6e"}}>{l}</div>
            </div>,
            i<a.length-1 && <div key={"d"+i} style={{width:1,height:32,background:"rgba(255,255,255,0.09)"}}/>
          ])}
        </div>
      </div>

      {/* ── ROUTE ── */}
      <div style={{padding:"0 20px 20px",overflowX:"auto"}}>
        <div style={{display:"flex",alignItems:"center",minWidth:"max-content",background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.06)",borderRadius:7,padding:"12px 16px"}}>
          {[{dot:"#6b82c0",name:"Tokyo",dates:"Aug 18–20"},null,{dot:"#c08080",name:"Kyoto",dates:"Aug 22–24"},null,{dot:"#60c090",name:"Osaka",dates:"Aug 26–27"},null,{dot:"#8a7f6e",name:"Home",dates:"Aug 28"}].map((item,i)=>
            item ? (
              <div key={i} style={{display:"flex",flexDirection:"column",gap:2}}>
                <div style={{width:7,height:7,borderRadius:"50%",background:item.dot,marginBottom:5}}/>
                <div style={{fontFamily:"'Unbounded',sans-serif",fontSize:10,color:"#fdfaf5"}}>{item.name}</div>
                <div style={{fontSize:8,color:"#8a7f6e",letterSpacing:"0.08em"}}>{item.dates}</div>
              </div>
            ) : (
              <div key={i} style={{flex:1,minWidth:44,height:1,background:"linear-gradient(90deg,rgba(255,255,255,0.13),rgba(255,255,255,0.04))",margin:"0 8px",marginBottom:18,position:"relative"}}>
                <span style={{position:"absolute",right:-6,top:-8,fontSize:11,color:"rgba(255,255,255,0.18)"}}>›</span>
              </div>
            )
          )}
        </div>
      </div>

      {/* ── TABS ── */}
      <div style={{display:"flex",padding:"0 20px",marginBottom:14,alignItems:"center",overflowX:"auto"}}>
        {[["all","All"],["tokyo","Tokyo"],["kyoto","Kyoto"],["osaka","Osaka"]].map(([city,label],i,a)=>{
          const active=filter===city, c=city!=="all"?CITY_COLORS[city]:null;
          return (
            <button key={city} onClick={()=>setFilter(city)} style={{
              padding:"7px 13px",fontSize:9,letterSpacing:"0.2em",textTransform:"uppercase",
              color:active?(c?c.text:"#fdfaf5"):"#8a7f6e",
              background:active?(c?c.bg:"rgba(255,255,255,0.07)"):"transparent",
              border:`1px solid ${active?(c?c.border:"rgba(255,255,255,0.18)"):"rgba(255,255,255,0.07)"}`,
              borderRight:i<a.length-1?"none":undefined,
              borderRadius:i===0?"5px 0 0 5px":i===a.length-1?"0 5px 5px 0":"0",
              transition:"all .18s",whiteSpace:"nowrap",
            }}>{label}</button>
          );
        })}
        <div style={{flex:1}}/>
        <div style={{display:"flex",alignItems:"center",gap:5,marginLeft:10}}>
          {saving
            ? <div style={{width:7,height:7,border:"1.5px solid rgba(255,255,255,0.12)",borderTop:"1.5px solid #fdfaf5",borderRadius:"50%"}} className="spinner"/>
            : <div style={{width:6,height:6,borderRadius:"50%",background:"#60c090"}}/>}
          <span style={{fontSize:7,color:"#8a7f6e",letterSpacing:"0.12em",textTransform:"uppercase"}}>{saving?"saving":"synced"}</span>
        </div>
      </div>

      {/* ── CARDS ── */}
      <div style={{padding:"0 20px",display:"flex",flexDirection:"column",gap:9}}>
        {visible.map((item,idx)=>{
          const c=CITY_COLORS[item.city], isCol=collapsed[item.id];
          const files = item.files||[];
          return (
            <div key={item.id} data-card-id={item.id} className="fadeup card"
              draggable onDragStart={e=>onDragStart(e,item.id)} onDragOver={onDragOver} onDrop={e=>onDrop(e,item.id)}
              onTouchStart={e=>onTouchStart(e,item.id)} onTouchMove={onTouchMove} onTouchEnd={onTouchEnd}
              style={{background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.065)",borderRadius:9,overflow:"hidden",position:"relative",animationDelay:`${idx*.04}s`,cursor:"grab",transition:"background .12s"}}
            >
              <div style={{position:"absolute",left:0,top:0,bottom:0,width:3,background:c.accent}}/>

              {/* header */}
              <div style={{padding:"13px 12px 11px 20px",display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:10}}>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:9,letterSpacing:"0.14em",color:"#8a7f6e",marginBottom:3,fontFamily:"'Unbounded',sans-serif",fontWeight:300}}>{item.date}</div>
                  <div style={{fontFamily:"'Shippori Mincho',serif",fontSize:17,fontWeight:600,color:"#fdfaf5",lineHeight:1.25,wordBreak:"break-word"}}>{item.title}</div>
                </div>
                <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:5,flexShrink:0}}>
                  <div style={{display:"flex",alignItems:"center",gap:5}}>
                    {files.length>0 && <span style={{fontSize:9,color:"#8a7f6e"}}>📎{files.length}</span>}
                    <span style={{fontSize:7,letterSpacing:"0.22em",textTransform:"uppercase",padding:"3px 7px",borderRadius:3,background:c.bg,color:c.text,border:`1px solid ${c.border}`}}>{CITY_LABELS[item.city]}</span>
                  </div>
                  <div style={{display:"flex",gap:4}}>
                    <button className="edit-btn" onClick={e=>{e.stopPropagation();setEditCard({...item,activities:[...(item.activities||[])],files:[...(item.files||[])],transit:item.transit?{...item.transit}:undefined});}}
                      style={{width:26,height:26,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:5,color:"#8a7f6e",fontSize:12,cursor:"pointer",transition:"all .15s"}}
                    >✎</button>
                    <button onClick={()=>toggleCollapse(item.id)}
                      style={{width:26,height:26,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:5,color:"#8a7f6e",fontSize:10,cursor:"pointer",transform:isCol?"rotate(-90deg)":"rotate(0deg)",transition:"transform .2s"}}
                    >▾</button>
                  </div>
                </div>
              </div>

              {/* body */}
              {!isCol && (
                <div>
                  {item.note && (
                    <div style={{margin:"0 12px 10px 20px",padding:"7px 10px",background:"rgba(255,255,255,0.03)",borderLeft:"2px solid rgba(255,255,255,0.09)",fontSize:10,color:"#8a7f6e",fontStyle:"italic",lineHeight:1.55,borderRadius:"0 3px 3px 0"}}>
                      {item.note}
                    </div>
                  )}

                  {item.activities && (
                    <div style={{padding:"0 12px 12px 20px",display:"flex",flexDirection:"column"}}>
                      {item.activities.map((act,ai)=>{
                        const key=`${item.id}-${ai}`, isDone=checked[key];
                        return (
                          <div key={ai} onClick={()=>toggleCheck(key)}
                            style={{display:"flex",alignItems:"flex-start",gap:9,padding:"6px 0",borderBottom:"1px solid rgba(255,255,255,0.035)",cursor:"pointer"}}>
                            <span style={{fontSize:8,color:"#8a7f6e",marginTop:3,minWidth:16,flexShrink:0}}>{String(ai+1).padStart(2,"0")}</span>
                            <span style={{fontSize:11,color:isDone?"#5a5550":"#f5f0e8",flex:1,lineHeight:1.45,textDecoration:isDone?"line-through":"none",textDecorationColor:"rgba(255,255,255,0.15)",transition:"color .2s"}}>{act}</span>
                            <div style={{width:17,height:17,borderRadius:"50%",flexShrink:0,marginTop:1,display:"flex",alignItems:"center",justifyContent:"center",background:isDone?"#c0392b":"transparent",border:`1px solid ${isDone?"#c0392b":"rgba(255,255,255,0.12)"}`,transition:"all .2s",fontSize:8,color:"white"}}>{isDone?"✓":""}</div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {item.transit && (
                    <div style={{padding:"2px 12px 14px 20px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                      <div style={{display:"flex",alignItems:"center",gap:10}}>
                        <span style={{fontFamily:"'Unbounded',sans-serif",fontSize:12,color:"#fdfaf5"}}>{item.transit.from}</span>
                        <span style={{fontSize:14,color:"#8a7f6e"}}>→</span>
                        <span style={{fontFamily:"'Unbounded',sans-serif",fontSize:12,color:"#fdfaf5"}}>{item.transit.to}</span>
                      </div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontSize:11,color:"#f5f0e8"}}>{item.transit.time}</div>
                        <div style={{fontSize:9,color:"#b8912a",marginTop:2}}>{item.transit.cost}</div>
                      </div>
                    </div>
                  )}

                  {/* FILES STRIP */}
                  {files.length > 0 && (
                    <div style={{padding:"0 12px 14px 20px"}}>
                      <div style={{fontSize:8,letterSpacing:"0.2em",textTransform:"uppercase",color:"#8a7f6e",marginBottom:8}}>Documents & Screenshots</div>
                      <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                        {files.map((f,fi)=>{
                          const isImg = f.type?.startsWith("image/");
                          return (
                            <div key={fi} className="file-chip" onClick={()=>setLightbox(f)}
                              style={{position:"relative",cursor:"pointer",borderRadius:6,overflow:"hidden",border:"1px solid rgba(255,255,255,0.1)",background:"rgba(255,255,255,0.04)",transition:"background .15s"}}>
                              {isImg ? (
                                <div style={{width:72,height:72}}>
                                  <img src={f.url} alt={f.name} className="img-thumb"/>
                                </div>
                              ) : (
                                <div style={{width:72,height:72,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:4,padding:6}}>
                                  <span style={{fontSize:22}}>{f.type?.includes("pdf")?"📄":"📎"}</span>
                                  <span style={{fontSize:8,color:"#8a7f6e",textAlign:"center",wordBreak:"break-all",lineHeight:1.3}}>{f.name?.slice(0,18)}</span>
                                </div>
                              )}
                              <button className="chip-del" onClick={e=>{e.stopPropagation();removeFile(item.id,f.url);}}
                                style={{position:"absolute",top:3,right:3,width:16,height:16,borderRadius:"50%",background:"rgba(0,0,0,0.7)",border:"none",color:"white",fontSize:9,display:"flex",alignItems:"center",justifyContent:"center",opacity:0,transition:"opacity .15s",cursor:"pointer"}}>✕</button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}

        <button className="add-btn" onClick={addCard} style={{border:"1px dashed rgba(255,255,255,0.11)",borderRadius:9,padding:"14px 20px",background:"transparent",color:"#8a7f6e",fontSize:11,letterSpacing:"0.14em",textTransform:"uppercase",cursor:"pointer",transition:"all .18s",display:"flex",alignItems:"center",justifyContent:"center",gap:9}}>
          <span style={{fontSize:17,lineHeight:1}}>＋</span> Add day / event
        </button>
        <div style={{textAlign:"center",fontSize:8,letterSpacing:"0.2em",color:"rgba(255,255,255,0.15)",padding:"2px 0",textTransform:"uppercase"}}>hold & drag to reorder</div>
      </div>

      {/* ── BOTTOM BAR ── */}
      <div style={{position:"fixed",bottom:0,left:0,right:0,background:"rgba(10,10,10,0.97)",backdropFilter:"blur(24px)",borderTop:"1px solid rgba(255,255,255,0.07)",padding:"11px 20px 28px",display:"flex",justifyContent:"space-between",alignItems:"center",zIndex:100}}>
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2}}>
          <div style={{fontFamily:"'Unbounded',sans-serif",fontSize:14,color:"#fdfaf5"}}>{doneCount}</div>
          <div style={{fontSize:7,letterSpacing:"0.2em",textTransform:"uppercase",color:"#8a7f6e"}}>Done</div>
        </div>
        <div style={{width:1,height:26,background:"rgba(255,255,255,0.07)"}}/>
        <div style={{width:44,height:44,position:"relative"}}>
          <svg width="44" height="44" viewBox="0 0 44 44" style={{transform:"rotate(-90deg)"}}>
            <circle cx="22" cy="22" r="18" fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="3"/>
            <circle cx="22" cy="22" r="18" fill="none" stroke={pct===100?"#60c090":"#c0392b"} strokeWidth="3"
              strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round" style={{transition:"stroke-dashoffset .5s ease,stroke .4s"}}/>
          </svg>
          <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Unbounded',sans-serif",fontSize:10,color:"#fdfaf5"}}>{pct}%</div>
        </div>
        <div style={{width:1,height:26,background:"rgba(255,255,255,0.07)"}}/>
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2}}>
          <div style={{fontFamily:"'Unbounded',sans-serif",fontSize:14,color:"#fdfaf5"}}>{allKeys.length}</div>
          <div style={{fontSize:7,letterSpacing:"0.2em",textTransform:"uppercase",color:"#8a7f6e"}}>Total</div>
        </div>
        <div style={{width:1,height:26,background:"rgba(255,255,255,0.07)"}}/>
        <button onClick={share} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2,background:"none",border:"none",padding:0,cursor:"pointer"}}>
          <span style={{fontSize:18}}>🔗</span>
          <span style={{fontSize:7,letterSpacing:"0.2em",textTransform:"uppercase",color:"#8a7f6e"}}>Share</span>
        </button>
      </div>

      {/* ── EDIT SHEET ── */}
      {editCard && (
        <EditSheet
          card={editCard}
          onSave={saveCard}
          onDelete={id=>setConfirmDel(id)}
          onClose={()=>setEditCard(null)}
          onUpload={attachFile}
          onRemoveFile={removeFile}
          onViewFile={setLightbox}
        />
      )}

      {/* ── DELETE CONFIRM ── */}
      {confirmDel && (
        <div className="overlay" onClick={()=>setConfirmDel(null)} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.72)",zIndex:300,display:"flex",alignItems:"center",justifyContent:"center",padding:24}}>
          <div onClick={e=>e.stopPropagation()} style={{background:"#1c1c1c",border:"1px solid rgba(255,255,255,0.11)",borderRadius:13,padding:24,maxWidth:300,width:"100%"}}>
            <div style={{fontFamily:"'Shippori Mincho',serif",fontSize:17,color:"#fdfaf5",marginBottom:10}}>Delete this card?</div>
            <div style={{fontSize:10,color:"#8a7f6e",lineHeight:1.65,marginBottom:22}}>Removes the card, activities, and attached files. Can't be undone.</div>
            <div style={{display:"flex",gap:10}}>
              <button onClick={()=>setConfirmDel(null)} style={{flex:1,padding:10,background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:7,color:"#8a7f6e",fontSize:10}}>Cancel</button>
              <button onClick={()=>deleteCard(confirmDel)} style={{flex:1,padding:10,background:"rgba(192,57,43,0.18)",border:"1px solid rgba(192,57,43,0.4)",borderRadius:7,color:"#e08070",fontSize:10}}>Delete</button>
            </div>
          </div>
        </div>
      )}

      {/* ── LIGHTBOX ── */}
      {lightbox && (
        <div className="overlay" onClick={()=>setLightbox(null)} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.9)",zIndex:400,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:20,gap:16}}>
          {lightbox.type?.startsWith("image/") ? (
            <img src={lightbox.url} alt={lightbox.name} className="lightbox-img"/>
          ) : (
            <div style={{color:"#fdfaf5",fontSize:14,textAlign:"center"}}>
              <div style={{fontSize:48,marginBottom:12}}>📄</div>
              <div>{lightbox.name}</div>
            </div>
          )}
          <div style={{display:"flex",gap:12}}>
            <a href={lightbox.url} target="_blank" rel="noreferrer"
              style={{padding:"9px 18px",background:"rgba(255,255,255,0.1)",border:"1px solid rgba(255,255,255,0.2)",borderRadius:7,color:"#fdfaf5",fontSize:10,letterSpacing:"0.14em",textDecoration:"none",cursor:"pointer"}}>
              Open
            </a>
            <button onClick={()=>setLightbox(null)} style={{padding:"9px 18px",background:"transparent",border:"1px solid rgba(255,255,255,0.12)",borderRadius:7,color:"#8a7f6e",fontSize:10,letterSpacing:"0.14em"}}>
              Close
            </button>
          </div>
        </div>
      )}

      {/* ── TOAST ── */}
      {toast && (
        <div className="toastin" style={{position:"fixed",bottom:94,left:"50%",transform:"translateX(-50%)",background:"rgba(22,22,22,0.97)",border:"1px solid rgba(255,255,255,0.12)",borderRadius:8,padding:"10px 18px",fontSize:11,color:"#fdfaf5",whiteSpace:"nowrap",zIndex:500,letterSpacing:"0.05em"}}>
          {toast}
        </div>
      )}
    </div>
  );
}

// ── EDIT SHEET COMPONENT ───────────────────────────────────────────────────────
function EditSheet({ card, onSave, onDelete, onClose, onUpload, onRemoveFile, onViewFile }) {
  const [draft,      setDraft]      = useState({ ...card, activities:[...(card.activities||[])], files:[...(card.files||[])], transit:card.transit?{...card.transit}:undefined });
  const [uploading,  setUploading]  = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const lastActRef  = useRef(null);
  const fileInputRef= useRef(null);

  const set     = (k,v) => setDraft(d=>({...d,[k]:v}));
  const setAct  = (i,v) => setDraft(d=>{ const a=[...d.activities]; a[i]=v; return {...d,activities:a}; });
  const addAct  = ()    => { setDraft(d=>({...d,activities:[...d.activities,""]})); setTimeout(()=>lastActRef.current?.focus(),40); };
  const removeAct=(i)   => setDraft(d=>({...d,activities:d.activities.filter((_,j)=>j!==i)}));
  const setTrans= (k,v) => setDraft(d=>({...d,transit:{...d.transit,[k]:v}}));
  const toggleTransit   = () => setDraft(d=>d.transit?{...d,transit:undefined,activities:d.activities||[""]}:{...d,transit:{from:"",to:"",time:"",cost:""},activities:undefined});

  const handleFiles = async (files) => {
    if (!files?.length) return;
    setUploading(true);
    for (let file of Array.from(files)) {
      try {
        const result = await uploadFile(card.id, file);
        onUpload(card.id, result);
        setDraft(d=>({...d,files:[...d.files,result]}));
      } catch(e) {}
    }
    setUploading(false);
  };

  const handleDrop = e => {
    e.preventDefault(); setDragActive(false);
    handleFiles(e.dataTransfer.files);
  };

  const iStyle = { width:"100%",border:"none",borderBottom:"1px solid rgba(255,255,255,0.09)",padding:"7px 0",fontSize:12,color:"#f5f0e8",background:"transparent",fontFamily:"'DM Mono',monospace" };
  const lbl    = txt => <div style={{fontSize:8,letterSpacing:"0.22em",textTransform:"uppercase",color:"#8a7f6e",marginBottom:5,marginTop:18}}>{txt}</div>;

  return (
    <>
      <div className="overlay" onClick={onClose} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.62)",zIndex:200}}/>
      <div className="sheet" style={{position:"fixed",bottom:0,left:0,right:0,zIndex:210,background:"#161616",borderRadius:"18px 18px 0 0",border:"1px solid rgba(255,255,255,0.09)",borderBottom:"none",maxHeight:"92vh",display:"flex",flexDirection:"column"}}>

        {/* handle */}
        <div style={{padding:"12px 20px 0",flexShrink:0}}>
          <div style={{width:38,height:4,borderRadius:2,background:"rgba(255,255,255,0.13)",margin:"0 auto 16px"}}/>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:6}}>
            <div style={{fontFamily:"'Shippori Mincho',serif",fontSize:18,color:"#fdfaf5"}}>Edit Card</div>
            <div style={{display:"flex",gap:8}}>
              <button onClick={()=>onDelete(card.id)} style={{padding:"6px 12px",background:"rgba(192,57,43,0.1)",border:"1px solid rgba(192,57,43,0.25)",borderRadius:6,color:"#c08070",fontSize:9,letterSpacing:"0.14em"}}>Delete</button>
              <button onClick={onClose} style={{padding:"6px 10px",background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.09)",borderRadius:6,color:"#8a7f6e",fontSize:12}}>✕</button>
            </div>
          </div>
        </div>

        {/* scrollable body */}
        <div style={{overflowY:"auto",padding:"0 20px 140px",flex:1}}>

          {lbl("Date / Label")}
          <input style={iStyle} value={draft.date} onChange={e=>set("date",e.target.value)} placeholder="e.g. Aug 18 · Day 1"/>

          {lbl("Title")}
          <input style={{...iStyle,fontSize:15,fontFamily:"'Shippori Mincho',serif"}} value={draft.title} onChange={e=>set("title",e.target.value)} placeholder="Day title"/>

          {lbl("City")}
          <div style={{display:"flex",gap:6,flexWrap:"wrap",marginTop:3}}>
            {Object.entries(CITY_LABELS).map(([city,label])=>{
              const c=CITY_COLORS[city],active=draft.city===city;
              return (
                <button key={city} onClick={()=>set("city",city)} style={{padding:"6px 11px",borderRadius:5,fontSize:9,letterSpacing:"0.14em",border:`1px solid ${active?c.border:"rgba(255,255,255,0.08)"}`,background:active?c.bg:"transparent",color:active?c.text:"#8a7f6e",cursor:"pointer",transition:"all .14s"}}>
                  {label}
                </button>
              );
            })}
          </div>

          {lbl("Note")}
          <textarea style={{...iStyle,minHeight:54,paddingTop:6,lineHeight:1.55}} value={draft.note||""} onChange={e=>set("note",e.target.value)} placeholder="Optional subtitle or reminder..."/>

          {/* transit toggle */}
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginTop:20,marginBottom:4}}>
            <div style={{fontSize:8,letterSpacing:"0.22em",textTransform:"uppercase",color:"#8a7f6e"}}>Transit Card</div>
            <button onClick={toggleTransit} style={{padding:"5px 11px",borderRadius:5,fontSize:8,letterSpacing:"0.1em",border:`1px solid ${draft.transit?"rgba(155,128,192,0.4)":"rgba(255,255,255,0.09)"}`,background:draft.transit?"rgba(155,128,192,0.13)":"transparent",color:draft.transit?"#c0a8e0":"#8a7f6e"}}>
              {draft.transit?"✓ On":"Off"}
            </button>
          </div>

          {draft.transit ? (
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 14px"}}>
              {[["From","from"],["To","to"],["Duration","time"],["Cost","cost"]].map(([label,key])=>(
                <div key={key}>
                  <div style={{fontSize:8,color:"#8a7f6e",marginTop:14,marginBottom:4,letterSpacing:"0.14em",textTransform:"uppercase"}}>{label}</div>
                  <input style={iStyle} value={draft.transit[key]||""} onChange={e=>setTrans(key,e.target.value)} placeholder={label}/>
                </div>
              ))}
            </div>
          ) : (
            <>
              {lbl("Activities")}
              {(draft.activities||[]).map((act,i)=>(
                <div key={i} style={{display:"flex",alignItems:"center",gap:8,padding:"5px 0",borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
                  <span style={{fontSize:8,color:"#8a7f6e",minWidth:18,flexShrink:0}}>{String(i+1).padStart(2,"0")}</span>
                  <input
                    ref={i===draft.activities.length-1?lastActRef:null}
                    value={act} onChange={e=>setAct(i,e.target.value)}
                    onKeyDown={e=>{ if(e.key==="Enter"){e.preventDefault();addAct();} if(e.key==="Backspace"&&act===""&&draft.activities.length>1){e.preventDefault();removeAct(i);} }}
                    style={{flex:1,border:"none",background:"transparent",color:"#f5f0e8",fontSize:11,fontFamily:"'DM Mono',monospace",outline:"none",padding:"2px 0"}}
                    placeholder="Activity..."
                  />
                  {draft.activities.length>1 && (
                    <button onClick={()=>removeAct(i)} style={{background:"none",border:"none",color:"rgba(255,255,255,0.18)",fontSize:14,cursor:"pointer",padding:"0 2px",lineHeight:1,transition:"color .14s"}}
                      onMouseEnter={e=>e.target.style.color="#c0392b"} onMouseLeave={e=>e.target.style.color="rgba(255,255,255,0.18)"}
                    >✕</button>
                  )}
                </div>
              ))}
              <button onClick={addAct} style={{marginTop:10,padding:"8px 0",width:"100%",background:"transparent",border:"1px dashed rgba(255,255,255,0.1)",borderRadius:6,color:"#8a7f6e",fontSize:9,letterSpacing:"0.14em",cursor:"pointer"}}
                onMouseEnter={e=>{e.target.style.borderColor="rgba(255,255,255,0.22)";e.target.style.color="#fdfaf5";}}
                onMouseLeave={e=>{e.target.style.borderColor="rgba(255,255,255,0.1)";e.target.style.color="#8a7f6e";}}
              >＋ Add activity</button>
            </>
          )}

          {/* ── FILES ── */}
          {lbl("Documents & Screenshots")}

          {/* existing files */}
          {draft.files?.length>0 && (
            <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:12}}>
              {draft.files.map((f,fi)=>{
                const isImg=f.type?.startsWith("image/");
                return (
                  <div key={fi} style={{position:"relative",cursor:"pointer",borderRadius:6,overflow:"hidden",border:"1px solid rgba(255,255,255,0.1)",background:"rgba(255,255,255,0.04)"}}
                    onClick={()=>onViewFile(f)}>
                    {isImg ? (
                      <div style={{width:72,height:72}}><img src={f.url} alt={f.name} className="img-thumb"/></div>
                    ) : (
                      <div style={{width:72,height:72,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:4,padding:6}}>
                        <span style={{fontSize:22}}>{f.type?.includes("pdf")?"📄":"📎"}</span>
                        <span style={{fontSize:8,color:"#8a7f6e",textAlign:"center",wordBreak:"break-all",lineHeight:1.3}}>{f.name?.slice(0,18)}</span>
                      </div>
                    )}
                    <button onClick={e=>{e.stopPropagation();onRemoveFile(card.id,f.url);setDraft(d=>({...d,files:d.files.filter((_,j)=>j!==fi)}));}}
                      style={{position:"absolute",top:3,right:3,width:16,height:16,borderRadius:"50%",background:"rgba(0,0,0,0.75)",border:"none",color:"white",fontSize:9,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer"}}>✕</button>
                  </div>
                );
              })}
            </div>
          )}

          {/* drop zone */}
          <div className="drop-zone" onDragEnter={e=>{e.preventDefault();setDragActive(true);}}
            onDragOver={e=>{e.preventDefault();setDragActive(true);}}
            onDragLeave={()=>setDragActive(false)}
            onDrop={handleDrop}
            onClick={()=>fileInputRef.current?.click()}
            style={{border:`1px dashed ${dragActive?"rgba(255,255,255,0.35)":"rgba(255,255,255,0.12)"}`,borderRadius:8,padding:"20px 16px",textAlign:"center",cursor:"pointer",background:dragActive?"rgba(255,255,255,0.04)":"transparent",transition:"all .2s"}}>
            {uploading ? (
              <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
                <div style={{width:14,height:14,border:"2px solid rgba(255,255,255,0.15)",borderTop:"2px solid #fdfaf5",borderRadius:"50%"}} className="spinner"/>
                <span style={{fontSize:10,color:"#8a7f6e"}}>Uploading...</span>
              </div>
            ) : (
              <>
                <div style={{fontSize:22,marginBottom:6}}>📎</div>
                <div style={{fontSize:10,color:"#8a7f6e",lineHeight:1.6}}>Drop files here or tap to browse</div>
                <div style={{fontSize:9,color:"rgba(255,255,255,0.2)",marginTop:4}}>Screenshots, PDFs, confirmations</div>
              </>
            )}
          </div>
          <input ref={fileInputRef} type="file" multiple accept="image/*,.pdf,.doc,.docx" style={{display:"none"}} onChange={e=>handleFiles(e.target.files)}/>
        </div>

        {/* sticky save */}
        <div style={{position:"absolute",bottom:0,left:0,right:0,padding:"14px 20px 36px",background:"linear-gradient(transparent,#161616 28%)",flexShrink:0}}>
          <button onClick={()=>onSave(draft)}
            style={{width:"100%",padding:14,background:"rgba(192,57,43,0.88)",border:"none",borderRadius:10,color:"white",fontSize:11,letterSpacing:"0.2em",textTransform:"uppercase",cursor:"pointer",transition:"background .14s",fontFamily:"'DM Mono',monospace"}}
            onMouseEnter={e=>e.target.style.background="rgba(192,57,43,1)"}
            onMouseLeave={e=>e.target.style.background="rgba(192,57,43,0.88)"}
          >Save Changes</button>
        </div>
      </div>
    </>
  );
}
