// api/upload.js — Vercel Serverless Function
// Handles file uploads and deletes via Vercel Blob

import { put, del } from "@vercel/blob";

export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  if (!process.env.BLOB_READ_WRITE_TOKEN) {
    return res.status(500).json({ error: "BLOB_READ_WRITE_TOKEN not set. Add it from your Vercel Blob store." });
  }

  // ── UPLOAD ──
  if (req.method === "POST") {
    // Parse multipart manually using raw stream
    const { IncomingForm } = await import("formidable");
    const form = new IncomingForm({ maxFileSize: 20 * 1024 * 1024 }); // 20MB limit

    form.parse(req, async (err, fields, files) => {
      if (err) return res.status(400).json({ error: "Parse error" });

      const file = Array.isArray(files.file) ? files.file[0] : files.file;
      const cardId = Array.isArray(fields.cardId) ? fields.cardId[0] : fields.cardId;

      if (!file) return res.status(400).json({ error: "No file" });

      const fs = await import("fs");
      const buffer = fs.readFileSync(file.filepath);
      const filename = `${cardId}/${Date.now()}-${file.originalFilename}`;

      const blob = await put(filename, buffer, {
        access: "public",
        token: process.env.BLOB_READ_WRITE_TOKEN,
        contentType: file.mimetype,
      });

      return res.status(200).json({
        url:  blob.url,
        name: file.originalFilename,
        type: file.mimetype,
        size: file.size,
      });
    });
    return;
  }

  // ── DELETE ──
  if (req.method === "DELETE") {
    const { url } = req.body;
    if (!url) return res.status(400).json({ error: "No URL" });
    await del(url, { token: process.env.BLOB_READ_WRITE_TOKEN });
    return res.status(200).json({ ok: true });
  }

  res.status(405).json({ error: "Method not allowed" });
}
