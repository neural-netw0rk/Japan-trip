// api/state.js — Vercel Serverless Function
// Reads and writes the shared trip state to Vercel KV

const STATE_KEY = "japan-trip-2026-state";

export default async function handler(req, res) {
  // Vercel KV env vars are injected automatically once you link the KV store
  const KV_REST_API_URL   = process.env.KV_REST_API_URL;
  const KV_REST_API_TOKEN = process.env.KV_REST_API_TOKEN;

  if (!KV_REST_API_URL || !KV_REST_API_TOKEN) {
    return res.status(500).json({ error: "KV not configured. Add KV_REST_API_URL and KV_REST_API_TOKEN to your Vercel environment variables." });
  }

  const headers = {
    Authorization: `Bearer ${KV_REST_API_TOKEN}`,
    "Content-Type": "application/json",
  };

  if (req.method === "GET") {
    const r = await fetch(`${KV_REST_API_URL}/get/${STATE_KEY}`, { headers });
    const data = await r.json();
    if (!data.result) return res.status(200).json({});
    return res.status(200).json(JSON.parse(data.result));
  }

  if (req.method === "POST") {
    const body = JSON.stringify(req.body);
    await fetch(`${KV_REST_API_URL}/set/${STATE_KEY}`, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
    });
    return res.status(200).json({ ok: true });
  }

  res.status(405).json({ error: "Method not allowed" });
}
