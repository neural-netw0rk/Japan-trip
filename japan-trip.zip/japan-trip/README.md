# Japan Trip 2026 🗾

Your shared travel dashboard. Deploys to Vercel in about 5 minutes.

---

## Deploy Steps

### 1. Create a Vercel account
Go to https://vercel.com and sign up (free).

### 2. Add a KV Store (for syncing data)
- In your Vercel dashboard → **Storage** → **Create** → **KV**
- Name it anything (e.g. `japan-trip`)
- Once created, go to the KV store → click **Connect to Project** (or note the env vars)

### 3. Add a Blob Store (for file uploads)
- In your Vercel dashboard → **Storage** → **Create** → **Blob**
- Name it anything (e.g. `japan-files`)
- Connect it to your project

### 4. Deploy the project
**Option A — Drag and drop (easiest):**
- Go to https://vercel.com/new
- Drag this entire `japan-trip` folder into the browser
- Vercel auto-detects it as a Vite project
- Click Deploy

**Option B — Vercel CLI:**
```bash
npm install -g vercel
cd japan-trip
vercel
```

### 5. Link your storage
After deploying, go to your project settings → **Environment Variables** and make sure these are set (Vercel adds them automatically when you connect the stores):
- `KV_REST_API_URL`
- `KV_REST_API_TOKEN`
- `BLOB_READ_WRITE_TOKEN`

### 6. Share the URL
Once deployed, you'll get a URL like `japan-trip-abc.vercel.app`.
Send it to your friend — you both open it, everything syncs automatically.

**Tip:** On iPhone, open in Safari → Share → Add to Home Screen. It'll look and feel like an app.

---

## Features
- ✅ Check off activities as you go
- ✎ Edit card titles, dates, notes, activities
- 📎 Upload screenshots, PDFs, booking confirmations — attached to each day
- ⇅ Drag cards to reorder
- 🔗 Share button copies the URL
- 🟢 Live sync between you and your friend

---

## Local Development
```bash
npm install
npm run dev
```
Note: API routes won't work locally without Vercel CLI (`vercel dev`).
